# 反谋财害命器 · 截图搜题浮窗

**当前版本：v1.2.2**　（版本历史见 [CHANGELOG.md](CHANGELOG.md)）

> “浪费别人的时间等于谋财害命。”——这就是名字的由来

一个**不依赖浏览器**的 Windows 桌面浮窗程序：始终置顶、随便拖动、随时收起。
按 `Ctrl + Alt + Q` 框选屏幕上的题目，答案 / 解析 / 考点直接出现在浮窗里。

---

## 安装与启动

有两种分发形式，**推荐第一种**（不需要装 Python）：

### A. 免安装版（推荐）

压缩包里有 `反谋财害命器.exe` —— **双击就能用**，不装 Python、不装依赖。
第一次启动会弹出设置窗，填接口地址 / 模型 / API Key 即可（详见下文）。

### B. 源码版

需要本机有 **Python 3.10+**。双击 **`启动反谋财害命器.bat`**：

- 没有 `.venv` 时，脚本会**自动创建虚拟环境并安装依赖**（`requirements.txt`，走清华镜像），只需一次
- 装好后再次双击，直接启动（无控制台窗口）
- 如果这台电脑没有 Python，脚本会明确提示去装，或改用 A 方案

> 手动安装：`python -m venv .venv` → `.venv\Scripts\python -m pip install -r requirements.txt`

## 用法

| 操作 | 说明 |
| --- | --- |
| `Ctrl + Alt + Q` | 全局热键，任何时候都能唤起框选（游戏/全屏除外） |
| 「框选」按钮 | 同上，热键被占用时的备用入口 |
| 拖动上方深色条 | 移动浮窗位置（位置会被记住，下次原位打开） |
| **「—」＝两档最小化** | 第一下：收成**贴边悬浮小球**；打开小球右键菜单可再收一档 |
| 悬浮小球 | 58px 圆球，贴屏幕侧边；**单击展开**、拖动松手自动吸边、右键有菜单 |
| 托盘图标 | 第二档：完全隐藏，只留在任务栏**隐藏的图标**溢出区；点它或按热键回来 |
| 「复制」 | 把当前答案复制到剪贴板 |
| *（说明）* | 程序**不读也不写剪贴板**（除了这个「复制」按钮是你主动点的）；截图只在内存里直接发给模型 |
| 「清空」 | 清掉对话，回到初始提示 |
| 输入框回车 | 追问（“为什么”“换种解法”）或直接打字提问 |
| 右下角 | 拖拽改变窗口大小 |

框选时的操作：**按住左键拉框 → 松手即搜**；`Esc` 或**右键**取消。
光标是青色准星＋全屏十字线＋实时坐标，暗屏下也一眼看得见；拖拽时右上角实时显示选区像素尺寸。

### 两档最小化怎么用

```
浮窗  ──点「—」──▶  贴边小球  ──右键→「收进托盘」──▶  托盘图标（完全隐藏）
  ▲                    │                                    │
  └──点小球展开────────┘                                    │
  └────────────────点托盘图标 / 按 Ctrl+Alt+Q───────────────┘
```

小球和托盘图标都带右键菜单：展开窗口 / 截图搜题 / 收成悬浮球 / 收进托盘 / 退出。

## 答案长什么样

- **答案单独抽出来做成高亮大字条**：主题色淡底 + 描边圆角，15.5pt 加粗，一眼就能看到
- 下面才分「题目 / 解析 / 考点」三段排版，小标签用强调色，正文 10.5pt、行高 158%
- 字体统一用 **思源黑体（Noto Sans SC）**，比系统雅黑更细腻；正文、标签、输入框、菜单都是同一套
- 「复制」按钮**只复制答案那一段**，不用再手动挑

## 外观（两套主题）

标题栏的 **◐** 按钮（托盘/小球右键菜单里也有「外观」）可以随时切换，**不用重启**，选择记进 `config.json` 的 `theme`：

| 主题 | 风格 |
| --- | --- |
| **镭射** | 青蓝霓虹 + 深空黑，框选准星也是这一套青蓝，冷峻赛博 |
| **液态玻璃** | 低饱和灰调 + 燕麦白字；**抓取背后画面自己模糊**（不透字）+ 顶部镜面高光 + 内缘亮边 + 底部反光 |

切主题时这些一起变：窗口卡片、正文面板、按钮/输入框、菜单、**悬浮小球**、**托盘图标**、**截图准星颜色**。

想自己调色：编辑 `souti.py` 顶部的 `THEMES` 字典即可，改完重启生效。
关键旋钮——`card_fill` 的 alpha（越低越透）、`acrylic` 的 alpha（越低背景越清楚）、`panel_bg` 里三个 stop 的 alpha（正文面板明度）、`gloss_top`/`edge`（高光与亮边强度）。

> 玻璃的底是**程序自己抓的一帧背后画面**（构造时 + 每次截完图自动刷新），缩小再放大约 24px 半径做模糊，
> 只画在圆角路径内 —— 所以圆角是干净的、背后文字不会透出来。桌面内容变化后（比如翻页）想刷新，
> 右键菜单里点「刷新玻璃背景」即可（会闪一下）。
> 代价：拖动窗口时玻璃里显示的是"跟着窗口移动的那一帧"，桌面静止时完全正确，播视频时会有点滞后。

## 第一次使用 / 换 API Key

**不用改任何文件**：点右上角 **⚙**，填三项 → 点「测试连接」确认通了 → 保存。

| 字段 | 填什么 |
| --- | --- |
| 接口地址 `api_base` | 模型服务商的 OpenAI 兼容地址，DeepSeek 是 `https://api.deepseek.com` |
| 模型 `model` | 必须**支持图片输入**的模型，否则读不了截图 |
| API Key | 服务商后台创建的 key，只存本机 `config.json`，不会上传 |

首次启动如果没检测到 Key，程序会**自动弹出设置窗**。也可以手动编辑 `config.json`：

```json
{ "api_base": "https://api.deepseek.com", "model": "xxx-vision", "api_key": "sk-你自己的" }
```

（`api_key` 留空时，程序会去找环境变量，名字写在 `api_key_env` 里。）

## 发版（一条命令搞定）

```bash
.venv\Scripts\python.exe dev/release_all.py            # 用当前 __version__
.venv\Scripts\python.exe dev/release_all.py v1.2.0     # 指定新版本号
```

它会依次：打包 zip → 更新 `site/versions.json` → git commit → 推到 GitHub → 建 Release 并上传附件。
网页端 <https://hanlinbachelor.github.io/fhcmd/> 由 GitHub Actions 自动发布（推送 `site/` 即触发）。

- 仓库：<https://github.com/hanlinbachelor/fhcmd>
- 发布页：<https://github.com/hanlinbachelor/fhcmd/releases>
- GitHub 令牌保存在 `%LOCALAPPDATA%\hermes\secrets\github_fhcmd_token.txt`（仅本账户可读）；
  不用了去 <https://github.com/settings/tokens> 撤销并删掉该文件即可

> 注意：这台机器所在网络无法访问 `github.com` 网页，但 `api.github.com` 与 `github.io` 正常，
> 所以发布走 API、访问走 Pages，不受影响。

## 配置（`config.json`）

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `api_base` | `https://api.deepseek.com` | 兼容 OpenAI 格式的任意端点 |
| `model` | `deepseek-v4-flash-vision-exp` | 必须支持图片输入 |
| `api_key` | 空 | 留空则自动读环境变量 `HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY`，或本机 Hermes 的 `.env` |
| `hotkey` | `ctrl+alt+q` | 支持 `ctrl/alt/shift/win` + `q/a/s/w/e/d/f/z/x/c/v/1/space` 组合 |
| `max_tokens` | 4000 | 思考型模型会先花一部分在推理上 |
| `window` | — | 自动记录的位置/尺寸，不用手改 |

改完保存即生效（重启程序）。

## 实现要点

- **PySide6**（Qt6）无边框半透明窗口，`WindowStaysOnTopHint` 置顶，`Tool` 类型不占任务栏。
- 截图：`QScreen.grabWindow(0)` 抓整块虚拟桌面（多屏已合并），按 DPI 缩放系数换算选区，取**原始物理像素**（本机 2× 缩放，抓出来就是 2560×1600），所以发过去的小字依然清晰。
- 识别＋解题：直接把图丢给视觉模型，**不用装 OCR**。系统提示固定要求输出 `题目 / 答案 / 解析 / 考点` 四段；看不清的字用 ▢ 标记，禁止编造题干。
- 请求：`requests` 流式 SSE，字一个个吐到浮窗里，随时可点「停止」。
- 小图自动放大（长边 <900px 放大到 900），大图缩到 1600px，超过 1.4MB 转 JPEG，兼顾清晰度与 token。
- 全局热键：`user32.RegisterHotKey` + 独立线程消息循环，不依赖第三方库。
- 每次截图视为新题（清上下文，省钱、防串题）；文字追问则带上文。

## 目录

```
souti.py                  主程序（全部逻辑，单文件；版本号在文件顶部 __version__）
requirements.txt          依赖清单（PySide6-Essentials、requests）
config.json               本机配置（.gitignore 忽略；模板见 config.example.json）
CHANGELOG.md              版本记录
启动反谋财害命器.bat       启动器：优先跑 exe，其次用 .venv，没有就自动建环境装依赖
dist/反谋财害命器.exe      免安装版（PyInstaller 打出，发布包里的就是它）
icon.ico / icon.png       图标（桌面快捷方式用）
.venv/                    开发用运行环境（发布包不带，用户侧自动生成或用 exe）
site/                     版本下载站（index.html + versions.json + releases/ + serve.py）
dev/                      开发期自测脚本（截图链路、UI 快照、跨窗口剪贴板验证等）
```

## 版本下载站（分享给别人）

```bash
cd site
..\.venv\Scripts\python.exe serve.py --port 8000     # 或双击 启动下载站.bat
```

启动后会打印 `http://<本机IP>:8000`，打开就能选版本、下载。
发布新版本一条命令：`python add_release.py --version v1.2.0`（自动打包 + 算 sha256 + 更新页面）。
详见 [site/README.md](site/README.md)（含本地、公网、静态托管三种部署方式）。

## 版本与维护

- 版本号：`souti.py` 顶部 `__version__`（当前 v1.2.0），同一版本号会显示在**状态栏首屏**、**欢迎页右下**、
  **托盘提示**、**右键菜单底部**，一眼就能确认跑的是哪版
- 发版三步：改 `__version__` → 在 `CHANGELOG.md` 加一节 → `git commit -m "vX.Y.Z: 一句话"`
- 规则：**主**版本=改了用法/配置格式，**次**版本=加功能（新主题、新交互），**补**=修 bug/调颜色/改文案

### 直接用 git 记录（仓库已就位）

```bash
cd "D:/hermes/261020搜题浮窗"
git init
git add .
git commit -m "v1.0.0: 截图搜题浮窗首个版本"
```

已帮你准备好：
- `.gitignore`：排除 `.venv/`、`__pycache__/`、`config.json`（含 key 与本机窗口位置）、`error.log`、`dev/shots/`
- `.gitattributes`：统一换行（.py/.md/.json 用 LF，.bat 用 CRLF），避免 Windows 上满屏无意义 diff
- `config.example.json`：配置模板，别人 clone 后复制成 `config.json` 填自己的 key 即可

## 已知限制

- 全屏独占的游戏里，全局热键可能被游戏吞掉（Windows 限制），此时可用「框选」按钮。
- 公式以 LaTeX 源码显示（`$f(x)=x^3-3x+1$`），没有渲染成排版后的数学式。
- 模型只看图，不联网查题库；答案来自模型自身知识，遇到冷门题可能有错，重要考试别当唯一依据。
